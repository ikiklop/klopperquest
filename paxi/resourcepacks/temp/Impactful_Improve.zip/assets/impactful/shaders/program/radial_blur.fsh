#version 150

uniform sampler2D DiffuseSampler;
uniform vec2 center;
uniform float intensity;
uniform int samples;

in vec2 texCoord;
out vec4 fragColor;

vec3 getDistortedRGB(vec2 uv, vec2 c, float strR, float strG, float strB) {
    vec2 offset = uv - c;
    float r = length(offset);

    if (r < 0.001) {
        return texture(DiffuseSampler, uv).rgb;
    }

    float distortionR = 1.0 + strR * r * 1.0;
    float distortionG = 1.0 + strG * r * 0.5;
    float distortionB = 1.0 + strB * r * -1.0;

    vec2 uvR = clamp(c + offset * distortionR, 0.0, 1.0);
    vec2 uvG = clamp(c + offset * distortionG, 0.0, 1.0);
    vec2 uvB = clamp(c + offset * distortionB, 0.0, 1.0);

    return vec3(
    texture(DiffuseSampler, uvR).r,
    texture(DiffuseSampler, uvG).g,
    texture(DiffuseSampler, uvB).b
    );
}
void main() {
    vec2 dir = texCoord - center;
    float dist = length(dir);
    vec2 stepVec = dir * intensity * dist;

    float baseIntensity = intensity * 0.36;

    float strR_center = baseIntensity * 3.5;
    float strG_center = baseIntensity * 0.4;
    float strB_center = baseIntensity * 2.5;
    float strR_sample = baseIntensity * 3.8;
    float strG_sample = baseIntensity * 0.3;
    float strB_sample = baseIntensity * 2.7;

    vec3 accum = getDistortedRGB(texCoord, center, strR_center, strG_center, strB_center);

    for (int i = 1; i <= samples; ++i) {
        float scale = float(i) / float(samples);
        vec2 offset = stepVec * scale;
        accum += getDistortedRGB(clamp(texCoord + offset, 0.0, 1.0),
        center, strR_sample, strG_sample, strB_sample);
        accum += getDistortedRGB(clamp(texCoord - offset, 0.0, 1.0),
        center, strR_sample, strG_sample, strB_sample);
    }

    fragColor = vec4(accum / float(2 * samples + 1), 1.0);
}